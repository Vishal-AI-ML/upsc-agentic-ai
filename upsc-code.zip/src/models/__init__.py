"""Pydantic models and schemas."""
