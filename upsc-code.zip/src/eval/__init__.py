"""Offline evaluation suite (RAGAS)."""
