"""FastAPI application and routes."""
